#!/bin/bash

# -------------------------------------------------------------------
# INITIALIZATION FOR BLUETOOTH
# ERNREST LOTTER 
# ernest.lotter@mixtelematics.com
# -------------------------------------------------------------------