#!/bin/bash

# -------------------------------------------------------------------
# INITIALIZE BLUETOOTH RFCOMM SERIAL PORT
# ERNREST LOTTER 
# ernest.lotter@mixtelematics.com
# -------------------------------------------------------------------

# ========================= Configuration ===========================

BT_SERIAL_RFCOMM_CHANNEL=10
BT_SERIAL_RFCOMM_REC_HANDLE=0x999
BT_DEVICE=hci0
BT_SERIAL_RFCOMM_PORT=/dev/rfcomm0
BT_SERIAL_RFCOMM_CHECK_INTERVAL=1
BT_SERVICE_CHANGE_SLEEP_TIME=10
BT_SERVER_NAME=MIX6000-BLUETOOTH-DEMO
BT_SIGNAL_FILE=/home/root/mix-bt-alive
BT_PAUSE_TIME=2
BT_DRIVER_INIT_TIME=10
BT_MODULE=btwilink
BT_DRIVER_UTILITY=uim

# ======================== Initialization ===========================

# This initialization need to fork the uim utility and run dependent
# utilities - must be in the exec part of the service

# Kill pairing agent (if it exists)
for SIMPLE_AGENT_PID in `ps ax | grep 'mix-bt-agent' | awk '{print $1;}'`; do
    echo kill -9 $SIMPLE_AGENT_PID
    kill -9 $SIMPLE_AGENT_PID
done

# Kill RFCOMM listener agent (if it exists)
for RFCOMM_AGENT_PID in `ps ax | grep 'rfcomm watch' | awk '{print $1;}'`; do
    echo kill -9 $RFCOMM_AGENT_PID
    kill -9 $RFCOMM_AGENT_PID
done

# Disable kernel level bluetooth driver and polling utility
pkill -9 $BT_DRIVER_UTILITY
sleep $BT_PAUSE_TIME
modprobe -r $BT_MODULE
sleep $BT_PAUSE_TIME

# Enable kernel level bluetooth driver and polling utility
modprobe $BT_MODULE
sleep $BT_PAUSE_TIME
$BT_DRIVER_UTILITY&
sleep $BT_DRIVER_INIT_TIME

# Disable the Bluetooth adapter
echo hciconfig $BT_DEVICE down
hciconfig $BT_DEVICE down

# Enable the Bluetooth adapter
echo hciconfig $BT_DEVICE up
hciconfig $BT_DEVICE up

# Set device name
hciconfig $BT_DEVICE name $BT_SERVER_NAME

# Remove record handle (if it exist)
echo sdptool del $BT_SERIAL_RFCOMM_REC_HANDLE
sdptool del $BT_SERIAL_RFCOMM_REC_HANDLE

# Add serial port service
echo sdptool add --handle=$BT_SERIAL_RFCOMM_REC_HANDLE --channel=$BT_SERIAL_RFCOMM_CHANNEL SP
sdptool add --handle=$BT_SERIAL_RFCOMM_REC_HANDLE --channel=$BT_SERIAL_RFCOMM_CHANNEL SP

# Enable discoverability
echo hciconfig $BT_DEVICE piscan
hciconfig $BT_DEVICE piscan

# Ensure RFCOMM device released
rfcomm release $BT_SERIAL_RFCOMM_PORT

# Remove file to signal to mix6000 service
rm -f $BT_SIGNAL_FILE

# ============================= Main ================================

# Start pairing agent - allow any MAC to connect
/usr/lib/bluez4/test/mix-bt-agent $BT_DEVICE&

# Listen for incoming RFCOMM connection - (watch handles disconnects and reconnects)
rfcomm watch $BT_SERIAL_RFCOMM_PORT $BT_SERIAL_RFCOMM_CHANNEL&

# Stop and start mix6000 application service depending on state of RFCOMM connection
BT_SERIAL_RFCOMM_PORT_AVAILABLE=false

echo "Starting RFCOMM connection detection loop"
while true; do
    BT_SERIAL_RFCOMM_PORT_AVAILABLE_PREV=$BT_SERIAL_RFCOMM_PORT_AVAILABLE

    if [ -e $BT_SERIAL_RFCOMM_PORT ]; then
        BT_SERIAL_RFCOMM_PORT_AVAILABLE=true
    else
        BT_SERIAL_RFCOMM_PORT_AVAILABLE=false
    fi

    # Detect change in RFCOMM port availability
    if [ $BT_SERIAL_RFCOMM_PORT_AVAILABLE != $BT_SERIAL_RFCOMM_PORT_AVAILABLE_PREV ]; then

        # Detect rising edge of RFCOMM port availability
        if [ $BT_SERIAL_RFCOMM_PORT_AVAILABLE == true ]; then
            echo "Detected $BT_SERIAL_RFCOMM_PORT available"
            echo "Restarting mix6000 service"
            # Create file to signal to mix6000 service
            touch $BT_SIGNAL_FILE
            systemctl restart mix6000
            sleep $BT_SERVICE_CHANGE_SLEEP_TIME
        fi

        # Detect falling edge of RFCOMM port availability
        if [ $BT_SERIAL_RFCOMM_PORT_AVAILABLE == false ]; then
            echo "Detected $BT_SERIAL_RFCOMM_PORT not available"
            echo "Restarting mix6000 service"
            # Remove file to signal to mix6000 service
            rm -f $BT_SIGNAL_FILE
            systemctl restart mix6000
            sleep $BT_SERVICE_CHANGE_SLEEP_TIME
        fi
    fi

    sleep $BT_SERIAL_RFCOMM_CHECK_INTERVAL
done
