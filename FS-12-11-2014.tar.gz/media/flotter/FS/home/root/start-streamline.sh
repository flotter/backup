modprobe gator
/home/root/gatord &
