# Configure GPIO pins mapped to SPI shift registers
# There is a chain of 4 times 8 bit registers from GPIO224 to GPIO255
GPIO_PATH=/sys/class/gpio
GPIO_ON=1
GPIO_OFF=0
GPIO_OUT=out
GPIO_IN=in
GPIO_RISING=rising
GPIO_FALLING=falling

RANGE1_HI=224
RANGE2_HI=225
RANGE3_HI=226
RANGE4_HI=227
RANGE5_HI=228
RANGE6_HI=229
RANGE7_HI=230
RANGE8_HI=231

nPULLUP1=232
nPULLUP2=233
nPULLUP3=234
nPULLUP4=235
nPULLUP5=236
nPULLUP6=237
nPULLUP7=238
nPULLUP8=239
nPULLUP9=240
nPULLUP10=241
nPULLUP11=242
nPULLUP12=243

SPARE_OUT=244
V3_3_PULLUP=245
GSM_EXT_ANT_EN=246
GSM_COMMS_ON=247
EXT_GPS_ANT=248
ANT_PWRON=249
SER3_TXEN=250
SER4_TXEN=251
CAN1_PWRON=252
CAN1_TXOFF=253
CAN2_PWRON=254
CAN2_TXOFF=255

MAGIX_IRQ1=D5
MAGIX_IRQ2=D6
PM_INTR=D7

for (( GPIO_PIN = 224; GPIO_PIN < 256; GPIO_PIN++ ))
do
    # Set value
    echo $GPIO_OFF > $GPIO_PATH/gpio$GPIO_PIN/value
    # Unexport
    echo $GPIO_PIN > $GPIO_PATH/unexport 
done

# Configure the GPIO interrupt pins used for SPI
# Export number = 32 x [BANK] + [PIN]
# 32 is the bits per bank
# [BANK]: A = 0, B =1, ...
# [PIN]:  GPIO[BANK]1 = 1, GPIO[BANK]2 = 2, ...
# GPIOD5 = 101, GPIOD6 = 102, GPIOD7 = 103

echo $GPIO_OFF > $GPIO_PATH/pio$MAGIX_IRQ1/value
echo $GPIO_OFF > $GPIO_PATH/pio$MAGIX_IRQ2/value
echo $GPIO_OFF > $GPIO_PATH/pio$PM_INTR/value

for (( GPIO_PIN = 101; GPIO_PIN < 104; GPIO_PIN++ ))
do
    # Unexport
    echo $GPIO_PIN > $GPIO_PATH/unexport
done

# Remove symbolic links to files used by SPI for polling gpio interrupts
rm -f /home/root/devs/spi_intr_pm
rm -f /home/root/devs/spi_intr_magix1
rm -f /home/root/devs/spi_intr_magix2

# Remove symbolic links to files used by SPI for communication
rm -f /home/root/devs/spi_comms_pm
rm -f /home/root/devs/spi_comms_magix1
rm -f /home/root/devs/spi_comms_magix2

# GPIOA2 is required by bluetooth
#rm -f /home/root/devs/wlan_en
#echo 2 > /sys/class/gpio/unexport

#rm -f /home/root/devs/bt_en
#echo 3 > /sys/class/gpio/unexport
rm -f /home/root/devs/gsm_reset
echo 4 > /sys/class/gpio/unexport
rm -f /home/root/devs/gsm_pwron
echo 5 > /sys/class/gpio/unexport
#rm -f /home/root/devs/led_codeplug
#echo 25 > /sys/class/gpio/unexport

rm -f /home/root/devs/relay1
rm -f /home/root/devs/gps_ant_int
rm -f /home/root/devs/gps_ant_ext
rm -f /home/root/devs/gsm_off
rm -f /home/root/devs/gps_on
rm -f /home/root/devs/led_function
rm -f /home/root/devs/led_c

rm -f /home/root/devs/tty_debug
rm -f /home/root/devs/tty_gsm
rm -f /home/root/devs/tty_gps
rm -f /home/root/devs/tty_S4
rm -r /home/root/devs/tty_bt
rm -r /home/root/devs/tty_dtcoSerial
rm -r /home/root/devs/tty_dtcoKline

rm -f /home/root/devs/adc_bat
rm -f /home/root/devs/adc_ign
rm -f /home/root/devs/adc_i1
rm -f /home/root/devs/adc_i2
rm -f /home/root/devs/adc_relay

#disable acc
echo 0 > /home/root/devs/accSysfs/buffer/enable
rm -f /home/root/devs/accSysfs
rm -f /home/root/devs/acc
