killall gatord 2> /dev/null
rmmod gator 2> /dev/null
